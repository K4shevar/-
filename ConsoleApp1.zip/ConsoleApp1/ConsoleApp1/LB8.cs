﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class LB8
    {
        // вар 20
        /*double f2(double x, double y1, double y2)
        {
            return y2 * y1;
        }
        double f1(double x, double y1, double y2)
        {
            return x * Math.Cos(y1 + y2);
        }*/
        double f2(double x, double y1, double y2)
        {
            return Math.Sin(x * y2);
        }
        double f1(double x, double y1, double y2)
        {
            return Math.Cos(y1 * y2 * x);
        }

        /// <summary>Определяет какую функцию нужно применить</summary>
        /// <param name="i">номер функции которую нужно использовать</param>
        double delegationFunc(int i, double x, double y1, double y2)
        {
            switch (i)
            {
                case 0:
                    return f1(x, y1, y2);

                case 1:
                    return f2(x, y1, y2);
            }
            return double.NaN;
        }

        double delegationFunc(int i, double a, double b)
        {
            switch (i)
            {
                case 0:
                    return a;

                case 1:
                    return b;
            }
            return double.NaN;
        }
        /// <param name="a">начало интервала, на котором ищем решения</param>
        /// <param name="b">конец интервала, на котором ищем решения</param>
        /// <param name="n">число точек внутри интервала, в которых ищется решение</param>
        /// <param name="funCount">кол-во функций в системе</param>
        /// <param name="y1">начальное значение функции 1 при х0</param>
        /// <param name="y2">начальное значение функции 2 при х0</param>
        void Eiler(double a, double b, int n, int funCount, double y1, double y2)
        {
            double h = (b - a) / n; // >шаг приращения
            double x = a;   //х, на котором ищем решение в данный момент
            double[,] y = new double[funCount, n]; //масив решений
            y[0, 0] = y1; y[1, 0] = y2;

            Console.WriteLine("Решение методом Эйлера");
            Console.WriteLine( "x" + "\t" + "y1" + "\t" + "y2");

            Console.WriteLine( x + "\t" + y[0, 0] + "\t" + y[1, 0]);

            for (int i = 1; i < n; i++)
            {
                x += h;
                for (int u = 0; u < funCount; u++)
                {
                    y[u, i] = y[u, i - 1] + h * delegationFunc(u, x, y[0, i - 1], y[1, i - 1]);
                }
                Console.WriteLine( x +"\t"+ y[0, i] + "\t" + y[1, i]);
            }
            Console.WriteLine();
        }

        void EilerKoshi(double a, double b, int n, int funCount, double y1, double y2)
        {
            double h = (b - a) / n; // шаг приращения
            double x = a;   //х, на котором ищем решение в данный момент
            double[,] y = new double[funCount, n]; //масив решений
            y[0, 0] = y1; y[1, 0] = y2;
            double[] additionalHalfY = new double[funCount];

            Console.WriteLine("Решение методом Эйлера-Коши");
            Console.WriteLine("x" + "\t" + "y1" + "\t" + "y2");

            Console.WriteLine(x + "\t" + y[0, 0] + "\t" + y[1, 0]);

            for (int i = 1; i < n; i++)
            {
                x += h;
                additionalHalfY[0] = y[0, i - 1];
                additionalHalfY[1] = y[1, i - 1];
                for (int u = 0; u < funCount; u++)
                {
                    additionalHalfY[u] = y[u, i - 1] + 0.5 * h * delegationFunc(u, x, y[0, i - 1], y[1, i - 1]);
                    y[u, i] = y[u, i - 1] + h * delegationFunc(u, x+0.5*h, additionalHalfY[0], additionalHalfY[1]);
                }
                Console.WriteLine(x + "\t" + y[0, i] + "\t" + y[1, i]);
            }
            Console.WriteLine();
        }

        void RungeKut4(double a, double b, int n, int funCount, double y1, double y2)
        {
            double h = (b - a) / n; // шаг приращения
            double x = a;   //х, на котором ищем решение в данный момент
            double[,] y = new double[funCount, n]; //масив решений
            y[0, 0] = y1; y[1, 0] = y2;
            double[,] additionalHalfY = new double[4,funCount];

            Console.WriteLine("Решение методом Рунге-Кутта");
            Console.WriteLine("x" + "\t" + "y1" + "\t" + "y2");

            Console.WriteLine(x + "\t" + y[0, 0] + "\t" + y[1, 0]);

            for (int i = 1; i < n; i++)
            {
                x += h;

                additionalHalfY[0, 0] = delegationFunc(0, x, y[0, i - 1], y[1, i - 1]); ;
                additionalHalfY[0, 1] = delegationFunc(1, x, y[0, i - 1], y[1, i - 1]); ;

                for (int u = 0; u < funCount; u++)
                {
                    additionalHalfY[1, u] = delegationFunc(u, x+0.5*h, 
                        y[0, i - 1] + 0.5 * h * additionalHalfY[0, 0], 
                        y[1, i - 1] + 0.5 * h * additionalHalfY[0, 1]);

                    additionalHalfY[2, u] = delegationFunc(u, x + 0.5 * h,
                        y[0, i - 1] + 0.5 * h * additionalHalfY[1, 0],
                        y[1, i - 1] + 0.5 * h * additionalHalfY[1, 1]);

                    additionalHalfY[2, u] = delegationFunc(u, x + h,
                       y[0, i - 1] + h * additionalHalfY[2, 0],
                       y[1, i - 1] + h * additionalHalfY[2, 1]);

                    y[u, i] = y[u, i - 1] + h / 6 * 
                        (delegationFunc(u, additionalHalfY[0, 0], additionalHalfY[0, 1]) +
                            2 * delegationFunc(u, additionalHalfY[1, 0], additionalHalfY[1, 1]) +
                                2 * delegationFunc(u, additionalHalfY[2, 0], additionalHalfY[2, 1]) +
                                        delegationFunc(u, additionalHalfY[3, 0], additionalHalfY[3, 1])
                            );
                }
                Console.WriteLine(x + "\t" + y[0, i] + "\t" + y[1, i]);
            }
            Console.WriteLine();
        }


        private static void Main4(string[] args)
        {
            LB8 lb8 = new LB8();
            // вар 20.
            double a = 2;
            double b = 5;
            double y1 = 0;
            double y2 = -3;
            int n = 40;

            lb8.Eiler(a, b, n, 2, y1, y2);
            lb8.EilerKoshi(a, b, n, 2, y1, y2);
            lb8.RungeKut4(a, b, n, 2, y1, y2);

            Console.Read();
        }

    }
}
