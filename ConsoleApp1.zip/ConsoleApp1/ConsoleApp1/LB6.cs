﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class LB6
    {

        
        // находим произведение матрицы на массив
        static double[] MatrUmnMas(double[,] a, double[] b, int n)
        {
            double s;
            double[] c = new double[n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    s = 0;
                    for (int l = 0; l < n; l++)
                    {
                        s += a[i, l] * b[l];
                    }
                    c[i] = s;
                }
            }
            //c = Norm(c);
            return c;
        }

        // нормализируем вектор
        static double[] Norm(double[] otv1)
        {
            double s = otv1.Max();
            for (int i = 0; i < otv1.Length; i++)
            {
                otv1[i] = otv1[i] / s;
            }
            return otv1;
        }

        static double[] CopyVect(double[] v2)
        {
            int n = v2.Length;
            double[] v1 = new double[n];
            for (int i = 0; i < n; i++)
            {
                v1[i] = v2[i];
            }
            return v1;
        }

        public static double[,] PodstanovkaSobZnach(double[,] a, double lambda, int n)
        {
            double[,] b = new double[n, n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    b[i, j] = a[i, j];
                }
                b[i, i] -= lambda;
            }

            return b;
        }

        // меняет местами ряды матрицы (если а (0,0) = 0)
        public static double[,] replaceRow(double[,] A, int n)
        {
            double temp;
            for (int t = 1; t < n; t++)// шаг по рядам
                if (A[t, 0] != 0) 
                {
                    for (int y = 0; y < n; y++)
                    {
                        temp = A[0, y];
                        A[0, y] = A[t, y];
                        A[t, y] = temp;
                    }
                    return A;
                }
            return A;
        }

        public static double[] Gauss(double[,] A1)
        {
            int n = A1.GetLength(0);
            double[,] A = new double[n, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    A[j,i] = A1[j, i];
                }
            }

            
            double[] vect = new double[n];
            vect[n-1] = 1;


            // прямой ход
            for (int i = 0; i < n; i++)// шаг по рядам
            {

                if (A[0, 0] == 0) // при условии что первый коэфицент не равен 0
                                  // меняем первую строчку на др.
                {
                    A = replaceRow(A, n);     
                } 

                for (int j = n - 1; j >= 0; j--)// шаг по колонкам <---
                {
                    if (A[i, i] != 0)
                    {
                        //делим всю строку на первый коэфицент
                        A[i, j] /= A[i, i];
                    }
                    
                    //из каждой строки вычитаем строку №i,
                    //умноженную на первый коэффицент строки
                    for (int k = i + 1; k <= n-1; k++) // шаг по рядам (для обнуления)
                    {
                        if (i < n - 1)
                            //A[i, j] - коэффицент при неизвестном (колонка) i строки
                            //A[k, i] - "первый" коэффицент уменьшаемого
                            A[k, j] -= A[i, j] * A[k, i];
                    }
                }
                

            }
            //обратный ход 
            for (int i = n - 3; i >= 0; i--)
            {
                for (int j = n - 1; j >= i; j--)// шаг по колонкам <---
                {
                    //из каждой строки вычитаем строку №i+1,
                    //умноженную на первый коэффицент строки
                    for (int k = i; k >= 0; k--) // шаг по рядам (для обнуления)
                    {
                        //A[i+1, j] - коэффицент при неизвестном (колонка) i+1 строки
                        //A[k, i] - "первый" коэффицент уменьшаемого
                        A[k, j] -= A[i + 1, j] * A[k, i + 1];
                    }
                }
            }
            /* по итогу получаем, матрицу, где n-1 неизвестных поочередно зависят от неизвестной под № n
             подставив в неизвестную под номером n - "1" найдем остальные.
            
                  ПРИМЕР:
              
              1x   0   0   -555z  =   0
              0   1y   0   6z     =   0
              0   0   1t   222z   =   0
              0   0   0   1z      =   0 */
            for (int i = 0; i < n - 1; i++)
            {
                vect[i] = -A[i, n - 1];
            }
            return vect;
        }

        public static double[,] transpMatrix(double[,] a)
        {
            int n = a.GetLength(0);
            double[,] a1 = new double[n, n];

            for (int i = 0; i < n; i++)
            {
                for (int r = 0; r < n; r++)
                {
                    a1[i, r] = a[r, i];
                }
            }
            return a1;
        }

        public static double scalarMultiply(double[] Vect, double[] Vect2)
        {
            int n = Vect.Length;
            double res = 0;
            for (int i = 0; i < n; i++)
            {
                res += Vect[i] * Vect2[i];
            }
            return res;
        }

        public static double[] divisionVect(double[] Vect, double num)
        {
            int n = Vect.Length;
            double[] res = new double[n];
            for (int i = 0; i < n; i++)
            {
                res[i] = Vect[i] / num;
            }
            return res;
        }

        public static double[,] ConvertMatrixToFindNextOwnValues(double[,] a, double[] ownVect, double ownVal)
        {
            int n = ownVect.Length;
            double[,] a1 = new double[n, n];
            //используемые формулы
            //A-lambda1*ownVect*ownVect1(transponent.) = A1   где 

            //(AT-lambda*E)ownVect@ = 0
            // если А симетричная то ownVect1 = ownVect@
            //ownVect1 = ownVect@ / (ownVect,ownVect@) - скалярное произведение


            double[,] at = transpMatrix(a);
            at = PodstanovkaSobZnach(at, ownVal, n);
            double[] ownVect1 = Gauss(at);
            double scalM = scalarMultiply(ownVect, ownVect1);
            ownVect1 = divisionVect(ownVect1, scalM);




                //умножение вертикального вектора на горизонтальный (транспонированый)
            for (int i = 0; i < n; i++)
            {
                for (int l = 0; l < n; l++)
                {
                    a1[i,l] = ownVect[i] * ownVect1[l];
                }
            }

            // вычитание матриц
            for (int i = 0; i < n; i++)
            {
                for (int l = 0; l < n; l++)
                {
                    a1[i, l] = a[i, l] - ownVal*a1[i, l];
                }
            }

            return a1;
        }

        public static double[] findFirstOwnsValVector(double[,] a,
                                            double[] x0) // начальное приближение
                                                         // (x c прошлой итерации)                                               
        {
            int n = a.GetLength(0);
            double eps = 0.001;
            double[] x;

            int iter = 0;
            double lambda0; // лямда с итерации к ( c прошлой итерации)
            double lambda; //лямда с итерации к+1 ( c текущей итерации)
            double max; // для условия окончания сета


            //Console.WriteLine("{0,5} {1,5} {2,5} {3,5} {4,5} ", "k", "x1", "x2", "x3", "lambda");
            //Console.WriteLine("{0,5} {1,5} {2,5} {3,5}", iter, x0[0], x0[1], x0[2]);


            iter++;
            // нулевая итерация (задаем лямбда 0-евой)
            x = MatrUmnMas(a, x0, n);
            lambda0 = x[0] / x0[0];

            //Console.WriteLine("{0,5} {1,5} {2,5} {3,5} ", iter, x[0], x[1], x[2]);

            x0 = CopyVect(x);
            do
            {
                iter++;
                x = MatrUmnMas(a, x0, n);
               
                lambda = x[1] / x0[1];
               
                max = Math.Abs(lambda - lambda0);
                
                // нужно для того, чтобы значения х0 заменить х
                // и наоборот. - для того, чтобы в случае обрыва цикла получить 
                // среднюю лямду как x0[i] / lastIterX[i];

                
                x0 = CopyVect(x);
                
                lambda0 = lambda;

            } while (max > eps);

            //lambda = AverageLambda(lastIterX, x0);

            x0 = Norm(x0);
            double[] result = new double[n + 1];
            result[0] = lambda;
            for(int i = 0; i < n; i++)
            {
                result[i + 1] = x0[i];
            }

            return result;
        }

        public static double[] iterOwnValues(double[,] A, 
                                            double[] x0) //начальное приближение

        {
            int n = A.GetLength(0);
            double[,] a = new double[n, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    a[j, i] = A[j, i];
                }
            }
            double eps = 0.0001;
            double max;  // для условия окончания счета
            int iter = 0;
            double[] lambdaList = new double[n];

            double[] x; // текущ. итер


            double[] x0Lambda = findFirstOwnsValVector(a, x0);
            double lambda1 = x0Lambda[0];
            for (int i = 0; i < n; i++)
            {
                x0[i] = x0Lambda[i+1];
            }


            a = ConvertMatrixToFindNextOwnValues(a, x0, lambda1);
            
            //Console.WriteLine("{0,5} {1,5} {2,5} {3,5}", iter, x0[0], x0[1], x0[2]);
            double lambda2; // следующая лямбда (следующее собственноe значение)
            lambdaList[0] = lambda1;

            iter++;
            //x0[0] = 0; 
            

            // добавить условие если MatrUmnMas(a, x0, n) выдает (0,0,0,) изменить х0



            x = MatrUmnMas(a, x0, n);
            
            for (int j = 1; j < n-1; j++)
            {       
                iter = 1;
                do
                {
                    x = MatrUmnMas(a, x, n);

                    //lambda2 = (x1[1] - x[1] * lambda1) / (x[1] - x0[1] * lambda1);
                    lambda2 = x[1] / x0[1];
                    

                    //Console.WriteLine("{0,5} {1,5} {2,5} {3,5} {4,5}", iter, x[0], x[1], x[2], lambda2);

                    x0 = CopyVect(x);

                    
                    max = Math.Abs(lambda2 - lambda1);
                    lambda1 = lambda2;
                    iter++;
                } while (max > eps);


                //lambda2 = AverageLambda(x0, x);
                x0 = Norm(x0);
                a = ConvertMatrixToFindNextOwnValues(a, x0, lambda2);

                lambdaList[j] = lambda2;
 
            }
            double S = 0;
            for (int i = 0; i < n-1; i++)
            {
                S += lambdaList[i];
            }

            lambdaList[n - 1] = FindMatrixTrace(A) - S;
            return lambdaList;
        }

        public static double FindMatrixTrace(double[,] matrix)
        {
            double S = 0;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                S += matrix[i, i];
            }
            return S;
        }

        private static void Main4(string[] args)
        {
            double[,] A1 = { { 2.9497,  -8.7224,   -13.989,   6.5990 },
                            { 4.6102,  -13.269,   -21.272,    10.314 },
                            { 6.3919,  -18.646,   -29.905,   14.300 },
                            { 5.3881,  -15.501,   -24.861,  12.054  } };


            double[,] A = { { 0.46329,  23.325,   5.6599,   3.3563 },
                            { 0.37616,  19.986,   4.8497,    2.7251 },
                            {-0.42388,  -21.495,   -5.2159,   -3.0708 },
                            { 0.28498, 15.141,   3.6742, 2.0646  } };
            Console.WriteLine("метод лаверье");
            int n = A.GetLength(0);
            double[][] cobV = new double[n][];
            double[] x0 = { 1, 1, 1 ,1};
            double[] ownVals = iterOwnValues(A,x0);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Cобственное значение = " + (ownVals[i]));
                cobV[i] = Gauss(PodstanovkaSobZnach(A, ownVals[i], n));
                Console.WriteLine("\t\t\t\tСобственный вектор");
                for (int r = 0; r < n; r++)
                    Console.Write("\t" + cobV[i][r]);
                Console.WriteLine("");
            }
            Console.WriteLine("метод фадеева");

           double[][] cobV1 = new double[n][];
            double[] x01 = { 1, 1, 0, 0 };
            ownVals = iterOwnValues(A, x01);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Cобственное значение = " + (ownVals[i]));
                cobV1[i] = Gauss(PodstanovkaSobZnach(A, ownVals[i], n));
                Console.WriteLine("\t\t\t\tСобственный вектор");
                for (int r = 0; r < n; r++)
                    Console.Write("\t" + cobV1[i][r]);
                Console.WriteLine("");
            }
            Console.Read();
        }
    }
}
