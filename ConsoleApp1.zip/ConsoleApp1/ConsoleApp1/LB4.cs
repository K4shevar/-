﻿using System;

namespace ConsoleApp1
{
    internal class LB4
    {

        double Norma(double[,] a, int n)
        {
            double res = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    res += a[i, j] * a[i, j];
                }
            }
            res = Math.Sqrt(res);
            return res;
        }
        // задание функции.
        private double func(double[] x, int i)
        {
            double res = 0;
            switch (i)
            {
                case 0:// x =
                    res = Math.Cos(x[1]+0.5)-2;
                    break;

                case 1:// y =
                    res = (Math.Sin(x[0]) - 1) / 2;
                    break;
            }
            return res;
        }
        //построение матрицы Якоби.
        private double MatrJacobi(double[] x, int i, int j)
        {
            double res = 0;
            switch (i)
            {
                case 0:
                    switch (j)
                    {
                        case 0:
                            res = Math.Cos(x[0])/2;
                            break;
                        case 1:
                            res = 0;
                            break;
                    }
                    break;
                case 1:
                    switch (j)
                    {
                        case 0:
                            res = 0;
                            break;
                        case 1:
                            res = -(Math.Sin(x[1]) - 1) / 2;
                            break;
                    }
                    break;
            }
            return res;
        }
        public double[] simpte_iter()
        {
            //размерность
            int n = 2;
            // счетчик итерац.
            int iter = 0;

            // c прошлой итерации
            double[] x0 = new double[n];
            // с текущ итерац
            double[] x = new double[n];
            double[,] a = new double[n, n];
            //начальн приближение
            x0[0] = 0; x0[1] = 0;

            // для условия окончания сета
            double max;
            double eps = 0.0001;

            do
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        a[i, j] = MatrJacobi(x0, i, j);
                    }
                }

                // проверка условия сходимости. 
                if (iter == 1)
                {
                    if (Norma(a, n) <= 0 || Norma(a, n) >1)
                    {
                        Console.WriteLine("не выполнено условие сходимости, норма = " + Norma(a,n));
                        return new double[n];
                    }
                } 
                

                for (int i = 0; i < n; i++)
                {
                    x[i] = func(x0, i);
                }

                max = Math.Abs(x[0] - x0[0]);
                for (int i = 1; i < n; i++)
                {
                    if (Math.Abs(x[i] - x0[i]) > max)
                    {
                        max = Math.Abs(x[i] - x0[i]);
                    }
                }

                x0 = x;
                iter++;
            }
            while ((max > eps) || (iter < 20));
            return x;
        }






        // метод ньютона
        //задание элементов матрицы Якоби.
        private double jacobian(double[] x, int i, int j)

        {
            double res = 0;
            switch (i)
            {
                case 0:
                    switch (j)
                    {
                        case 0:
                            res = 2;
                            break;

                        case 1:
                            res = Math.Sin(x[1]+0.5);
                            break;
                    }
                    break;

                case 1:
                    switch (j)
                    {
                        case 0:
                            res = - Math.Cos(x[0]+1);
                            break;

                        case 1:
                            res = -1;
                            break;
                    }
                    break;
            }
            return res;
        }
        private double func2(double[] x, int i)

        {
            double res = 0;
            switch (i)

            {
                case 1://  sin x — 2y - 1 = 0
                    res = Math.Sin(x[0]+1) - x[1] + 1;
                    break;

                case 0://  cos(y+0,5) - x - 2 = 0
                    res = Math.Cos(x[1]) + 2*x[0] - 2;
                    break;

            }
            return res;

        }
        public double[] Nyuton()

        {
            int n = 2;
            int iter = 0;
            double[] dx = new double[n];
            double[] x = new double[n];
            double[] f = new double[n];// матр якоби
            double[,] a = new double[n, n];
            x[0] = -0.003; x[1] = 0.5;
            double max, eps = 0.0001;

            do
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        a[i, j] = jacobian(x, i, j);
                    }
                }

                for (int i = 0; i < n; i++)
                {
                    f[i] = -1 * func2(x, i);
                }

                dx = Ch_M.LB1.Gauss(n, n, f, a);
                
                max = Math.Abs(dx[0]);
                for (int i = 1; i < n; i++)
                {
                    if (Math.Abs(dx[i]) > max)
                    {
                        max = Math.Abs(dx[i]);
                    }
                }

                for (int i = 0; i < n; i++)
                {
                    x[i] = x[i] - dx[i];
                }
                iter++;
            }
            while (max > eps);
            return x;
        }
        static void Main5(string[] args)
        {
            Console.WriteLine("Решение методом простых итераций");
            LB4 l = new LB4();
            double[] y = l.simpte_iter();
            
            
            Console.WriteLine("х = " + y[0]);
            Console.WriteLine("у = " + y[1]);
            Console.WriteLine("");

            double[] n = l.Nyuton();
            Console.WriteLine("Решение методом Ньютона");
            Console.WriteLine("y = " + n[0]);
            Console.WriteLine("x = " + n[1]);
            

            Console.Read();
        }
    }
}
