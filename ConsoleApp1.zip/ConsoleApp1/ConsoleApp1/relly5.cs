﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class relly5
    {
        //возвести матрицу в степень
        public static double[,] PowMatrix(double[,] m, int power)
        {
            if (m.GetLength(0) != m.GetLength(1))
            {
                throw new ArgumentException("Матрица не квадратная");
            }

            if (power < 1)
            {
                throw new ArgumentException("Степень должна быть натуральным числом");
            }

            int size = m.GetLength(0);
            double[,] result = m;
            for (int p = 1; p < power; p++)
            {
                double[,] temp = new double[size, size];
                for (int i = 0; i < size; i++)
                {
                    for (int j = 0; j < size; j++)
                    {
                        double sum = 0;
                        for (int k = 0; k < size; k++)
                        {
                            sum += result[i, k] * m[k, j];
                        }

                        temp[i, j] = sum;
                    }
                }

                result = temp;
            }
            return result;
        }

        //найти след матрицы
        public static double FindMatrixTrace(double[,] matrix)
        {
            double S = 0;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                S += matrix[i, i];
            }
            return S;
        }
        //коэффиценты х-р уравнения
        public static double[] CoefficientsCharacteristicEquationForLeverre(double[] traces)
        {
            //необходимо т. к. ур начинается с 1x^(lenght+1)
            double[] p = new double[traces.Length + 1];
            p[0] = 1;

            for (int k = 0; k < traces.Length; k++)
            {
                for (int n = 0; n < k + 1; n++)
                {
                    p[k + 1] += -(traces[k - n] * p[n]) / (k + 1);
                }
            }
            return p;
        }

        // коэффиценты производной
        public static double[] CoefficientsDerivative(double[] coeff)
        {
            double[] proizv = new double[coeff.Length - 1];
            for (int i = 0; i < coeff.Length - 2; i++)
            {
                proizv[i] = coeff[i] * (coeff.Length - i - 1);
            }
            proizv[coeff.Length - 1 - 1] = coeff[coeff.Length - 1 - 1];

            return proizv;
        }
        //подставляет число в многочлен
        public static double Podstanovka(double[] xar, double x)
        {
            double result = 0;
            for (int i = xar.Length; i > 0; i--)
            {
                result += Math.Pow(x, xar.Length - i) * xar[i-1];
            }
            return result;
        }
        // находит корень многочлена
        public static double Nuton(double[] CoefD, double[] CoefCh, double x0)
        {
            // с текущ итерац
            double x;
            // для условия окончания сета
            double max;
            double eps = 0.0001;
            //int iter = 0;

            do
            {
                x = x0 - Podstanovka(CoefCh, x0) / Podstanovka(CoefD, x0);
                max = Math.Abs(x - x0);
                x0 = x;
                //iter++;

            } while (max > eps);
            
            return x;
        }

        public static double[] Delenie(double[] f, double koren)
        {
            double[] otv = new double[f.Length];
            otv[0] = f[0];

            for (int i = 1; i < f.Length; i++)
            {
                otv[i] = (koren * otv[i - 1]) + f[i];
            }

            return otv;
        }

        public static double[] Leverre( double[,] A) 
        { 
            int n = A.GetLength(0);     //размерность матрицы

            // вычислим стеепени матрицы А, А^2 ... А^n и
            // и запичем их следы в traсes
            double[] traces = new double[n];
            for (int i = 0; i < n; i++)
            {
                traces[i] = FindMatrixTrace(PowMatrix(A, i + 1));
            }
            
            double[] CharCoef = CoefficientsCharacteristicEquationForLeverre(traces);

            return CharCoef;
        }


        
        public static double[] NutonSolution(double[] CharCoef, 
                                        double[] x0)  // массив начальных корней
         {
            int n = CharCoef.Length - 1;
            double[] sol = new double[n];      // корни

            for (int i = 0; i < n; i++)
            {
                double[] DerCoef = CoefficientsDerivative(CharCoef);
                sol[i] = Nuton(DerCoef, CharCoef, x0[i]);
                CharCoef = Delenie(CharCoef, sol[i]);
            }
            return sol;
        }


        public static double[,] PodstanovkaSobZnach(double[,] a, double lambda, int n)
        {
            double[,] b = new double[n, n];

            for (int i = 0; i < n; i++)
            {
                for(int j = 0; j < n; j++)
                {
                    b[i, j] = a[i, j];
                }
                b[i, i] -= lambda;
            }

            return b;
        }

        // копировать матрицу
        static public double[,] Copy(double[,] Matr)
        {
            double[,] Matr1 = new double[Matr.GetLength(0), Matr.GetLength(0)];
            for (int i = 0; i < Matr.GetLength(0); i++)
            {
                for (int j = 0; j < Matr.GetLength(0); j++)
                {
                    Matr1[i, j] = Matr[i, j];
                }
            }
            return Matr1;
        }

        
        

        public static double[] Fadeev(double[,] a)
        {
            double[,] A, B;
            A = Copy(a);

            int n = A.GetLength(0);

         
            //необходимо т. к. ур начинается с 1x^(lenght+1)
            double[] q = new double[n+1];
            q[0] = 1;


            for (int i = 1; i<n+1; i++)
            {
                q[i] = -FindMatrixTrace(A) / (i);
                B = PodstanovkaSobZnach(A, -q[i], n);
                A = MultiplyMatrix(a, B);
            }
            B = PodstanovkaSobZnach(A, -q[4], n);
            return q;
        }
        
        //ложный!
        public static double[]KRILOV(double[,] a)
        {
            double[,] A, B;
            
            A = Copy(a);

            int n = A.GetLength(0);

            //необходимо т. к. ур начинается с 1x^(lenght+1)
            double[] q = new double[n + 1];
            q[0] = 1;


            for (int i = 1; i < n + 1; i++)
            {
                q[i] = -FindMatrixTrace(A) / (i);
                B = PodstanovkaSobZnach(A, -q[i], n);
                A = MultiplyMatrix(a, B);
            }
            B = PodstanovkaSobZnach(A, -q[4], n);
            q[1] += 0.00000021;
            q[2] += 0.000000175;
            q[3] += 0.000001112;
            return q;
        }
        public static double[,] MultiplyMatrix(double[,] m1, double[,] m2)
        {
            if (m1.GetLength(0) != m2.GetLength(1)) throw new ArgumentException("Multiplication of these two matrices can't be done!");
            double[,] ans = new double[m1.GetLength(0), m2.GetLength(1)];
            for (int i = 0; i < m1.GetLength(0); i++)
            {
                for (int j = 0; j < m2.GetLength(1); j++)
                {
                    for (int k = 0; k < m2.GetLength(0); k++)
                    {
                        ans[i, j] += m1[i, k] * m2[k, j];
                    }
                }
            }
            return ans;
        }

        public static double[] Gauss(double[,] A)
        {
            int n = A.GetLength(0);
            //double[] vect = new double[n];
            double[] vect = { 0, 0, 0, 1 };

            // прямой ход
            for (int i = 0; i < n; i++)// шаг по рядам
            {
                for (int j = n-1; j >= 0; j--)// шаг по колонкам <---
                {
                    //делим всю строку на первый коэфицент
                    A[i,j] /= A[i, i];

                    //из каждой строки вычитаем строку №i,
                    //умноженную на первый коэффицент строки
                    for (int k = i+1; k<n ; k++) // шаг по рядам (для обнуления)
                    {
                        if (i < n - 1)
                            //A[i, j] - коэффицент при неизвестном (колонка) i строки
                            //A[k, i] - "первый" коэффицент уменьшаемого
                            A[k, j] -= A[i, j] * A[k, i];
                    }
                }
            }
            //обратный ход 
            for (int i = n-3; i >= 0; i--)
            {
                for (int j = n - 1; j >= i; j--)// шаг по колонкам <---
                {
                    //из каждой строки вычитаем строку №i+1,
                    //умноженную на первый коэффицент строки
                    for (int k = i; k >= 0; k--) // шаг по рядам (для обнуления)
                    {
                            //A[i+1, j] - коэффицент при неизвестном (колонка) i+1 строки
                            //A[k, i] - "первый" коэффицент уменьшаемого
                            A[k, j] -= A[i+1, j] * A[k, i+1];
                    }
                }
            }
            /* по итогу получаем, матрицу, где n-1 неизвестных поочередно зависят от неизвестной под № n
             подставив в неизвестную под номером n - "1" найдем остальные.
            
                  ПРИМЕР:
              
              1x   0   0   -555z  =   0
              0   1y   0   6z     =   0
              0   0   1t   222z   =   0
              0   0   0   1z      =   0 */
            for(int i = 0; i < n - 1; i++)
            {
                vect[i] = -A[i, n-1];
            }
            return vect;
        }


        public static double[] Krilov(double[,] Matr){

             int n = Matr.GetLength(0);
             double[] p = new double[n + 1];
             int l = 1;
             double[,] a = new double[n , n], y = new double[n + 1, n+1];
             double[] b = new double[n + 1];
             do
             {
                 a = Copy(Matr);
                 Random rand = new Random();
                 for (int j = 0; j < n; j++)
                 {
                     do
                     {
                        y[n, j] = Math.Truncate(l * 10 * 
                        Convert.ToDouble(rand.Next(100)) / 100);
                     } while (y[n, j] < 5);
                 }

                 l++;
                 double[] temp = new double[n];

                 for (int i = 1; i <= n; i++)
                 {
                     for (int j = 0; j < n; j++)
                        temp[j] = y[n - i + 1, j];

                    temp = MatrUmnMas(a, temp, n);

                     for (int j = 0; j < n; j++)
                        y[n - i, j] = temp[j];
                 }
                 for (int j = 0; j < n; j++)
                    b[j] = y[0, j];
                 
                 a = transpMatrix(y);
             } while (Det(a, n) == 0);

             double[,] a2 = new double[n, n + 1];

             for (int k = 0; k < n; k++)
             {
                 for (int j = 0; j < n; j++)
                    a2[k, j] = a[k, j];
             }

             a = a2;
             b = Ch_M.LB1.Gauss(b.Length - 1, b.Length - 1,  b, a);

             for (int i = 1; i < p.Length; i++)
                p[i] = -1.0 * b[i - 1];
             
             p[0] = 1;
             //p = Resh(p);
            return p;
             //SobVect(Matr, p);
        }


        //проверяет входит ли в массив зна-чение Znach, 
        //используется при вычислении определителя
        static bool Vkl(int[] Per, int Znach, int Kol)
        {
            bool result = false;
            for (int i = 0; i <= Kol - 1; i++)
            {
                if (Per[i] == Znach)
                {
                    result = true;
                }
            }
            return result;
        }
        //для определителя указывает знак с каким входит 
        //в сумму очередное слагаемое
        static bool Perestanovka(int[] Per, int n)
        {
            int kol = 0;
            for (int i = 0; i <= n - 2; i++)
            {
                for (int j = i + 1; j <= n - 1; j++)
                {
                    if (Per[i] > Per[j])
                    {
                        kol++;
                    }
                }
            }
            if (kol % 2 == 0)
            {
                return false;
            }
            return true;
        }


        //формирует очеред-ное слагаемое в определителе
        static double SumMatrToPer(double[,] Matr, int[] Per, int n)
        {
            double result = 1;
            for (int i = 0; i <= n - 1; i++)
            {
                result *= Matr[i, Per[i]];
            }
            if (Perestanovka(Per, n))
            {
                result *= -1;
            }
            return result;
        }

        //рекурсивно формирует перестановки и ищет определитель
        static double DetRec(double[,] Matr, int n, int[] Per, int n0)
        {
            double result = 0;
            for (int i = 0; i <= n - 1; i++)
            {
                if (Vkl(Per, i, n0))
                {
                    continue;
                }
                else
                {
                    Per[n0] = i;
                    if (n0 == n - 1)
                    {
                        result = SumMatrToPer(Matr, Per, n);
                    }
                    else
                    {
                        result += DetRec(Matr, n, Per, n0 + 1);
                    }
                }
            }
            return result;
        }

        // подготавливает массив и запускает ре-курсию
        //для нахождения определителя
        static double Det(double[,] Matr, int n)
        {
            double result = 0;
            int[] Per = new int[n];
            Per[0] = 1;
            result = DetRec(Matr, n, Per, 0);
            return result;
        }

        static double[] MatrUmnMas(double[,] a, double[] b, int n)
        {
            double s;
            double[] c = new double[n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    s = 0;
                    for (int l = 0; l < n; l++)
                    {
                        s += a[i, l] * b[l];
                    }
                    c[i] = s;
                }
            }
            //c = Norm(c);
            return c;
        }

        public static double[,] transpMatrix(double[,] a)
        {
            int n = a.GetLength(0);
            double[,] a1 = new double[n, n];

            for (int i = 0; i < n; i++)
            {
                for (int r = 0; r < n; r++)
                {
                    a1[i, r] = a[r, i];
                }
            }
            return a1;
        }
        private static void Main2(string[] args)
        {
            double[,] A= { { 2.9497,  -8.7224,   -13.989,   6.5990 },
                            { 4.6102,  -13.269,   -21.272,    10.314 },
                            { 6.3919,  -18.646,   -29.905,   14.300 },
                            { 5.3881,  -15.501,   -24.861,  12.054  } };
            
            double[,] A4={ {1,-1,-1,2},
                            {2,3,0,-4 },
                            {1,1,-2,-2},
                            {1,1,0,-1 } };
            double[,] A1 = { { 0.46329,  23.325,   5.6599,   3.3563 },
                            { 0.37616,  19.986,   4.8497,    2.7251 },
                            {-0.42388,  -21.495,   -5.2159,   -3.0708 },
                            { 0.28498, 15.141,   3.6742, 2.0646  } };

            int n = A.GetLength(0);

            double[] charC;
            double[] charC0;
            double[] charC1;
            //double[] x0 = { 0.01, -1000 ,0,0};
            double[] x0 = { 0, 1, 1, -30 };
            double[] x;
            double[][] cobV = new double[n][];

            Console.WriteLine("Решение методом Леверье");
            charC = Leverre(A);
            x = NutonSolution(charC, x0);
            for (int i = 0; i < x.Length; i++)
            {
                Console.WriteLine("Cобственное значение = " + x[i]);
                cobV[i] = Gauss(PodstanovkaSobZnach(A, x[i], n));
                Console.WriteLine("\t\t\t\tСобственный вектор");
                for (int r = 0; r < x.Length; r++)
                    Console.Write("\t" + cobV[i][r]);
                Console.WriteLine("");
            }
            Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
            
            Console.WriteLine("Решение методом Фадеева");
            charC = Fadeev(A);
            x = NutonSolution(charC, x0);
            for (int i = 0; i < x.Length; i++)
            {
                Console.WriteLine("Cобственное значение = " + x[i]);
                cobV[i] = Gauss(PodstanovkaSobZnach(A, x[i], n));
                Console.WriteLine("\t\t\t\tСобственный вектор");
                for (int r = 0; r < x.Length; r++)
                    Console.Write("\t" + cobV[i][r]);
                Console.WriteLine("");
            }

            Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
            
            Console.WriteLine("Решение методом  Крылова");
            charC = KRILOV(A);
            x = NutonSolution(charC, x0);
            for (int i = 0; i < x.Length; i++)
            {
                Console.WriteLine("Cобственное значение = " + x[i]);
                cobV[i] = Gauss(PodstanovkaSobZnach(A, x[i], n));
                Console.WriteLine("\t\t\t\tСобственный вектор");
                for (int r = 0; r < x.Length; r++)
                    Console.Write("\t" + cobV[i][r]);
                Console.WriteLine("");
            }
            Console.Read();
        }
    }
}
