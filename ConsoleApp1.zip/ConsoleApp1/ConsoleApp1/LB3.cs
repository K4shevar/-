﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class LB3
    {

        static double[] Givens(double[,] A, double[] B)
        {
            int Nn = 2;
            double[] x = new double[Nn];


            double B0 = B[0];
            double A00 = A[0,0];

            double A_0_1 = A[0, 1];
            double M = 0.0;
            double L, R;
            for (int i = 0; i < Nn - 1; i++)
            {
                for (int k = i + 1; k < Nn; k++)
                {
                    M = Math.Sqrt(A[i, i] * A[i, i] + A[k, i] * A[k, i]);
                    L = A[k, i] / M; //Вычислили A12
                    M = A[i, i] / M; //Вычислили B12
                    for (int j = 0; j < Nn; j++)
                    {
                        R = A[i, j];
                        A[i, j] = M * A[i, j] + L * A[k, j]; // {получили a1j}
                        A[k, j] = M * A[k, j] - L * R; // {получили a2j}
                    }
                    R = B[i];
                    B[i] = M * B[i] + L * B[k];
                    B[k] = M * B[k] - L * R;
                }
            }
            
            x[1] = B[1] / A[1, 1];

            x[0] = (B0 - A_0_1 * x[1]) / A00;
            return x;
        }
        
        static double[] vozm(int n, double eps)
        {
            double[] b2 = new double[n];
            for (int i = 0; i < n; i++)
            {
                b2[i] += eps;
            }
            return b2;
        }

        static double[] Regul(int n, double[,] a, double[] b)
        {
            double[,] AtA = new double[n, n];
            double[] Atb = new double[n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Atb[i] += a[j, i] * b[j]; // умножение трансп матриц на вектора 

                    for (int k = 0; k < n; k++)
                    {
                        AtA[i, j] += a[i, k] * a[j, k];// умножение трансп матр на матр
                    }
                }
            }
            double[,] AtA1 = new double[n, n];
            double[] Atb1 = new double[n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Atb1[i] += AtA[j, i] * Atb[j]; // умножение трансп матриц на вектора 

                    for (int k = 0; k < n; k++)
                    {
                        AtA1[i, j] +=AtA[i, k] * AtA[j, k];// умножение трансп матр на матр
                    }
                }
            }

            double eps = 0.05;
            double alpha = 0.0000001;


            double max;
            double[] x0;// в прошлой итерац
            double[] x01;// в конце текущ итер
            
            do
            {
                // (АтА+E(alpha))
                for (int i = 0; i < n; i++)
                {
                    AtA[i, i] += alpha;
                }

                x0 = Ch_M.LB1.Gauss(n, n, Atb, AtA);

                // (alpha)x0 + Atb
                for (int i = 0; i < n; i++)
                {
                    Atb[i] += alpha * x0[i];
                }

                x01 = Ch_M.LB1.Gauss(n, n, Atb, AtA);

                max = Math.Abs(x01[1] - x0[1]);
                for (int i = 1; i < n; i++)
                {
                    if ((Math.Abs(x01[1] - x0[1])) > max)
                    {
                        max = Math.Abs(x01[i] - x0[i]);
                    }
                }
            } while (max > eps);

            /*Console.WriteLine("кол-во итераций "+p);
            Console.WriteLine("");*/

            return x01;
        }
        

        static void Main1(string[] args)
        {
            double[] b1 = { 2.92, 2.41 };
            double[,] A1 = {  { 1.03, 0.991 },
                         { 0.991, 0.943 } };

            double[] b = { 2.51, 2.41 };
            double[,] A = {  { 1.03, 0.2973 },
                         { 0.991, 0.2829 } };
            Console.WriteLine("Решение методом регуляризаци");
            double[] r = Regul(2, A, b);
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine(r[i]);
            }
            Console.WriteLine("");


            Console.WriteLine("Решение методом Гивенса");
            foreach (double item in Givens(A, b))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");

           

            Console.ReadLine();
        }
    }
}
