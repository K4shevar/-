﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch_M
{
    internal class LB2
    {
        public static double[] Jacobi(double[,] A, double[] B, double eps, int N)
        {
            //иксы с прошлой терации
            double[] X = new double[N];

            //иксы на этой итерации
            double[] TempX = new double[N];

            // начельное приближение
            X[0] = 1; X[1] = 1; X[2] = 1;

            // норма, определяемая как наибольшая разность компонент столбца иксов соседних итераций
            double norm;

            int countOperation=0;

            do
            {
                for (int i = 0; i < N; i++)
                {
                    TempX[i] = B[i];

                    for (int g = 0; g < N; g++)
                    {
                        if (i != g)
                            TempX[i] -= A[i, g] * X[g];
                    }
                    TempX[i] /= A[i, i];
                }
                norm = Math.Abs(X[0] - TempX[0]);

                //находим максимальную норму
                for (int h = 0; h < N; h++)
                {
                    if (Math.Abs(X[h] - TempX[h]) > norm)
                        norm = Math.Abs(X[h] - TempX[h]);
                    X[h] = TempX[h];
                }

                countOperation += 1;

            } while (norm > eps);
            Console.WriteLine("кол-во итераций = " + countOperation);
            return X;
        }


        static double[] Zejdel(double[,] A, double[] B, double eps, int N)
        {
            //иксы, которые используем в текущей итерации
            double[] X = new double[N];
            //иксы с прошлой терации
            double[] X1 = new double[N];

            //иксы на этой итерации
            double[] TempX = new double[N];

            // начельные приближения
            X[0] = 1; X[1] = 1; X[2] = 1;
            X1[0] = 1; X1[1] = 1; X1[2] = 1;


            // норма, определяемая как наибольшая разность компонент столбца иксов соседних итераций
            double norm;

            int countOperation = 0;

            do
            {
                for (int i = 0; i < N; i++)
                {
                    TempX[i] = B[i];

                    for (int g = 0; g < N; g++)
                    {
                        if (i != g)
                        {
                            if(i != 0)
                                TempX[i] -= A[i, g] * X[g];
                            else
                                TempX[i] -= A[i, g] * X1[g];
                        }

                            
                    }
                    TempX[i] /= A[i, i];
                    
                    X[i] = TempX[i];
 
                }

               
                norm = Math.Abs(X1[0] - TempX[0]);

                //находим максимальную норму
                for (int h = 0; h < N; h++)
                {
                    if (Math.Abs(X1[h] - TempX[h]) > norm)
                        norm = Math.Abs(X1[h] - TempX[h]);
                    X1[h] = TempX[h];
                }

                countOperation += 1;

            } while (norm > eps);
            Console.WriteLine("кол-во итераций = "+countOperation);
            return X;// X[i] = w * TempX[i] + (1 - w) * X[i];
        }

        static double[] ZejdelEx(double[,] A, double[] B, double eps, int N, double w)
        {
            //иксы, которые используем в текущей итерации
            double[] X = new double[N];
            //иксы с прошлой терации
            double[] X1 = new double[N];

            //иксы на этой итерации
            double[] TempX = new double[N];

            // начельные приближения
            X[0] = 1; X[1] = 1; X[2] = 1;
            X1[0] = 1; X1[1] = 1; X1[2] = 1;


            // норма, определяемая как наибольшая разность компонент столбца иксов соседних итераций
            double norm;

            int countOperation = 0;

            do
            {
                for (int i = 0; i < N; i++)
                {
                    TempX[i] = B[i];

                    for (int g = 0; g < N; g++)
                    {
                        if (i != g)
                        {
                            if (i != 0)
                                TempX[i] -= A[i, g] * X[g];
                            else
                                TempX[i] -= A[i, g] * X1[g];
                        }
                    }
                    TempX[i] /= A[i, i];

                    X[i] = w * TempX[i] + (1 - w) * X1[i];
                }

                norm = Math.Abs(X1[0] - TempX[0]);

                //находим максимальную норму
                for (int h = 0; h < N; h++)
                {
                    if (Math.Abs(X1[h] - TempX[h]) > norm)
                        norm = Math.Abs(X1[h] - TempX[h]);
                    X1[h] = TempX[h];
                }

                //Console.WriteLine(X[0]+" "+ X[1] + " "+ X[2]+" | "+ countOperation);
                countOperation += 1;

            } while (norm > eps);
            Console.WriteLine("кол-во итераций = " + countOperation);
            
            return X;
        }


        static void Main1(string[] args)
        {
            double[] b = { 56.2234, 58.9772, 61.3645, 63.3853 };
            double[,] A = {  { 25.1000, 0.1063, 0.1276, 0.1488 },
                         { 0.0801, 24.2000, 0.1225, 0.1437 },
                         { 0.0750, 0.0963, 23.3000, 0.1387 },
                         { 0.0700, 0.0912, 0.1124,22.4000 } };


            Console.WriteLine("Решение методом Якоби");
            foreach (double item in Jacobi(A, b, 0.01, 3))
            {
                Console.WriteLine(item);
            }



            Console.WriteLine("");
            Console.WriteLine("Решение методом Зейделя");
            foreach (double item in Zejdel(A, b, 0.01, 3))
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("");
            Console.WriteLine("Решение обобщенным методом Зейделя");
            foreach (double item in ZejdelEx(A, b, 0.01, 3, 1.8))
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("");

            Console.ReadLine();
        }
    }
}
