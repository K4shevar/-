﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class LB9
    {

        // вар 20
        double f2(double x, double y1, double y2)
        {
            return y2 * y1;
        }
        double f1(double x, double y1, double y2)
        {
            return x * Math.Cos(y1 + y2);
        }


        /// <summary>Определяет какую функцию нужно применить</summary>
        /// <param name="i">номер функции которую нужно использовать</param>
        double delegationFunc(int i, double x, double y1, double y2)
        {
            switch (i)
            {
                case 0:
                    return f1(x, y1, y2);

                case 1:
                    return f2(x, y1, y2);
            }
            return double.NaN;
        }

        double delegationFunc(int i, double a, double b)
        {
            switch (i)
            {
                case 0:
                    return a;

                case 1:
                    return b;
            }
            return double.NaN;
        }

    }}