﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class lb13
    {
        void ff(double[] xr, double[] xi, double[] yr, double[] yi, int n, int ind)
        {
            double[,] res = new double[2, n + 1];
            int k = n;
            int log2 = 0;
            do
            {
                k = k / 2;
                log2 = log2 + 1;

            } while (k >= 2);

            int mm = 1;
            for (int m = 1; m <= log2; m++)
            {
                
                int m2 = mm * 2;
                double k1 = Math.Truncate(Math.Pow(2, (log2 - m)) - 1);
                int l1 = mm - 1;
                for (k = 1; k <= k1 + 1; k++)
                {
                    for (int l = 1; l <= l1 + 1; l++)
                    {
                        int j = m2 * (k - 1) + l;
                        int i = mm * (k - 1) + l;
                        double w = Math.PI * (l - 1) / mm;
                        double si = ind * Math.Sin(w);
                        double co = Math.Cos(w);
                        double ni = Math.Truncate(Math.Pow(2, (log2 - 1)) + i);
                        double jm = Math.Truncate(j + Math.Pow(2, (m - 1)));
                        double xa = xr[(int)ni] * co + xi[(int)ni] * si;
                        double xb = xi[(int)ni] * co - xr[(int)ni] * si;
                        yr[j] = xr[i] + xa;
                        yi[j] = xi[i] + xb;
                        yr[(int)jm] = xr[i] - xa;
                        yr[(int)jm] = xr[i] - xa;
                        yi[(int)jm] = xi[i] - xb;
                    }
                }
                for (int it = 1; it <= n; it++)
                {
                    xr[it] = yr[it];
                    xi[it] = yi[it];
                }
                mm = m2;
            }
            if (ind < 0) { return; }
            for (int i = 1; i <= n; i++)
            {
                xr[i] = xr[i] / n;
                xi[i] = xi[i] / n;
            }
            
            /*for (int i = 0; i < n; i++)
            {
                res[0, i] = xr[i];
                res[1, i] = xi[i];
            }
            return res;*/
        }
        void iff(double a, double b, double[] ar, double[] ai, double[] xr, double[] xi, int n, double eps, int ip)
        {
            double h = (b - a) / n;
            double a1, b1, w4, w5, w1, w2, w3; ;
             ff(ar, ai, xr, xi, n, ip);
            /*double[,] xx = 
            for (int i = 0; i < n; i++)
            {
                 xr[i] = xx[0, i] ;
                 ai[i] = xx[1, i] ;
            }*/

            for (int i = 1; i <= n; i++)
            {
                int k = i - 1;
                double w = k * 2 * Math.PI / (b - a);
                double c = Math.Cos(w * a);

                double s = Math.Sin(w * a);
                w = w * h * (b - a);
                if (w < eps)
                {
                    w4 = h - 2 * Math.PI * Math.PI * k * k * Math.Pow(h, 3) / Math.Pow((b
                   - a), 2);
                    w5 = 2 * Math.PI * k * h * h / (b - a);
                    a1 = w4 * ar[i] + ip * w5 * ai[i];
                    b1 = w4 * ai[i] - ip * w5 * ar[i];
                }
                else
                {
                    if (k == 0)
                    {
                        w1 = 0;
                        w3 = 0;
                    }
                    else
                    {
                        w1 = Math.Sin(2 * Math.PI * k / n) * (b - a) / (2 * Math.PI * k);
                        w2 = 2 * Math.Pow(Math.Sin(Math.PI * k / n), 2);
                        w3 = w2 * (b - a) / (2 * Math.PI * k);
                    }
                    w2 = 2 * Math.Pow(Math.Sin(Math.PI * k / n), 2);
                    a1 = w1 * ar[i] + ip * w3 * ai[i];
                    b1 = w1 * ai[i] - ip * w3 * ar[i];
                }
                ar[i] = a1 * c + b1 * s * ip;
                ai[i] = b1 * c - a1 * s * ip;
                if (ip > 0)
                {
                    ar[i] = ar[i] * n * n;
                    ai[i] = ai[i] * n * n;
                }
                ar[i] = ar[i] / n;
                ai[i] = ai[i] / n;
            }

/*            double[,] res = new double[2,n+1];
            for (int i = 0; i < n; i++)
            {
                res[0, i] = ar[i];
                res[1, i] = ai[i];
            }
            return res;*/
            
        }

        private static void Main(string[] args)
        {
            double a = -Math.PI;
            double b = Math.PI ;
/*
            double[]    ar = new double[513],
                        ai = new double[513];

           

            double[]    xr = new double[513],
                        xi = new double[513];

            int n = 512;
            double eps = 0.01;
            int ip = 1;
            double h = (b - a) / n;
            double x;


            for (int i = 0; i < 512; i++)
            {
                x = (i - 1) * h;
                // ar[i] = Math.Cos(x + Math.Pow(x, 3));
                ar[i] = Math.Exp(-x * x);
            }

            new lb13().iff(a, b, ar, ai, xr, xi,  n, eps, ip);
*/
            double[] ar = { 0, 0.0181287573, -0.0512355445, -0.024735435, 0.0125479826, 0.07614698972, -4.967456236, -0.0319999991, -0.031155254, -0.0209925325, -0.014154652795, -0.01147864877854, -9.577469411E-3, -6.8711285E-3, -5.21079427E-3, -4.05699999E-3, -3.2643683574E-3, -0.109655E-3 };
            double[] ai = { 0, 2.8658314755, -4.9313254564, -1.105614544, 5.1039244138, 2.4897525216, -0.214865425696, -0.789856542652, -0.656846531279, -1.133691496, -0.2252573611, -0.1405163489, -0.093875463114, -0.9376654834, -0.06542378961, -0.4712875632, -0.23254742, -0.200452545 };

            Console.WriteLine("\tОмега\tДейст. часть\t\tМнимая часть");
            for (int i = 0; i < ar.Length; i++)
            {
                Console.WriteLine(i+"\t"+(i*2*Math.PI / (b - a))+"\t"+ar[i]+"\t" + ai[i]);
            }
            Console.ReadKey();
        }

    }
}
