package ThirteenLB;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

public class ThirteenXML{
    public static void main(String[] args) throws TransformerException{
        String filepath = "ThirteenLB\\inputXML.xml";
        try {
            HandleDOM pd = new HandleDOM(filepath);
            List<Student> ls = pd.paurseXMLToGetStudents();

            for(Student s : ls){
                System.out.println(s.getFullName());
                System.out.println("средний бал в документе - " + s.getAverage());
                System.out.println("средний бал в действительности - " + s.getTrueAverage());
                s.setAverage(s.getTrueAverage());
                System.out.println("средний бал после исправления - " + s.getAverage());
            }

            pd.writeXMLToStudentAverage(ls);

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


    }
}
    
