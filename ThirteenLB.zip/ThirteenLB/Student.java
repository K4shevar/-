package ThirteenLB;
import java.util.Set;
import java.util.HashMap;

public class Student {
    private String fullName;
    private String numGroup;
    private String average;
    private HashMap<String,String> subjectMarks;
    

    public Student(String firstName, String lastName, String numGroup, HashMap<String,String> subjectMarks,String average){
        setFullName(firstName, lastName);
        setNumGroup(numGroup);
        setSubjectMarks(subjectMarks);
        setAverage(average);
    }
    public void setSubjectMarks(HashMap<String,String> subjectMarks){
        this.subjectMarks = subjectMarks;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAverage() {
        return average;
    }

    public String getNumGroup() {
        return numGroup;
    }

    public void setFullName(String firstName, String lastName) {
        this.fullName = firstName + " " + lastName;
    }

    public void setAverage(String average) {
        this.average = average;
    }

    public void setNumGroup(String numGroup) {
        this.numGroup = numGroup;
    }

    public String getTrueAverage(){
        float average = 0;
        int size = subjectMarks.size();
        Set<String> set = subjectMarks.keySet();
        for(String key:set) {
            average += Integer.parseInt((String)subjectMarks.get(key));
        }
        average /= size;
        return average+"";
    }

    
}

