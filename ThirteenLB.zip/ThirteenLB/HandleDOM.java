package ThirteenLB;

import java.io.File;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class HandleDOM {

    private Document document;
    private String filepath;

    public HandleDOM(String filepath)throws ParserConfigurationException, SAXException, IOException{
        this.filepath = filepath;
        
        File xmlFile = new File(filepath);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        document = builder.parse(xmlFile);
        document.getDocumentElement().normalize();
    }

    public List<Student> paurseXMLToGetStudents() {
        
        NodeList nodeList = document.getElementsByTagName("student");
            
        // создадим из него список объектов Student
        List<Student> studentList = new ArrayList<Student>();

        // Перебор поочередго каждого студента
        for (int i = 0; i < nodeList.getLength(); i++) {

            Node student = nodeList.item(i);
            
            NodeList studentTegs = student.getChildNodes();

            HashMap<String,String> subjectMarks = new HashMap<String,String>();
            String inputedAverage = "";

            //обработка дочерних тегов 
            for (int r=0; r < studentTegs.getLength(); r++ )
            {
                if(studentTegs.item(r).getNodeName() == "subject")
                {
                    NamedNodeMap attrSubj = studentTegs.item(r).getAttributes();
                    subjectMarks.put(attrSubj.getNamedItem("title").getNodeValue(),
                                            attrSubj.getNamedItem("mark").getNodeValue());
                } 
                else if (studentTegs.item(r).getNodeName() == "average")
                {
                    inputedAverage = studentTegs.item(r).getTextContent();
                }
                        
            }
            // Получение атрибутов каждого элемента
            NamedNodeMap attributes = student.getAttributes();

            studentList.add(new Student(
                            attributes.getNamedItem("firstname").getNodeValue(), 
                                attributes.getNamedItem("lastname").getNodeValue(),
                                    attributes.getNamedItem("groupnumber").getNodeValue(),
                                    subjectMarks, inputedAverage));                           
            }
        return studentList;
    }

    public void writeXMLToStudentAverage(List<Student> listStudent) throws TransformerException {
        NodeList nodeListStud = document.getElementsByTagName("student");
        NodeList nodeListAver = document.getElementsByTagName("average");

        int size = nodeListAver.getLength();
        for(int i = 0; i < size; i++){
            nodeListAver.item(i).getParentNode().removeChild(nodeListAver.item(i));
            size--;
            i--;
        }
        
        for(int i = 0; i < nodeListStud.getLength(); i++){
                
            Node el =  document.createElement("average");
            el.setTextContent(listStudent.get(i).getAverage());
            nodeListStud.item(i).appendChild(el);

        }
          
        
        

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(document);
        StreamResult result = new StreamResult(new File(filepath));
        transformer.transform(source, result);

    }
}
